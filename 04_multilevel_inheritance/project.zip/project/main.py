from project.sports_car import SportsCar

s = SportsCar()
print(s.drive())
print(s.move())
print(s.race())