from project.teacher import Teacher

t = Teacher()
print(t.sleeping())