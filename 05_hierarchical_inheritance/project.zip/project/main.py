from project.cat import Cat
from project.dog import Dog

c = Cat()
d = Dog()

print(c.eat())
print(c.meow())
print(d.eat())
print(d.bark())